def calculate_grade(correct: int, total: int = 10) -> dict:
    """
    Convert correct answer count to Uzbek grading scale.
    9-10 → 5 (A'lo)
    7-8  → 4 (Yaxshi)
    6    → 3 (Qoniqarli)
    0-5  → 2 (Qoniqarsiz)
    """
    if correct >= 9:
        grade  = 5
        status = "A'lo (Excellent)"
        emoji  = "🏆"
        passed = True
    elif correct >= 7:
        grade  = 4
        status = "Yaxshi (Good)"
        emoji  = "✅"
        passed = True
    elif correct == 6:
        grade  = 3
        status = "Qoniqarli (Satisfactory)"
        emoji  = "📋"
        passed = True
    else:
        grade  = 2
        status = "Qoniqarsiz (Failed)"
        emoji  = "❌"
        passed = False

    percentage = round((correct / total) * 100)

    return {
        "score":      correct,
        "total":      total,
        "percentage": percentage,
        "grade":      grade,
        "status":     status,
        "emoji":      emoji,
        "passed":     passed,
    }


def format_result_message(result: dict, student_name: str) -> str:
    """Format the final result message shown to the student."""
    lines = [
        f"{result['emoji']} *Natija — {student_name}*",
        "",
        f"To'g'ri javoblar: *{result['score']}/{result['total']}* ({result['percentage']}%)",
        f"Baho: *{result['grade']}* — {result['status']}",
        "",
    ]
    if result["passed"]:
        lines.append("✅ Topshiriq muvaffaqiyatli topshirildi!")
    else:
        lines.append("❌ Topshiriq qabul qilinmadi.")
        lines.append("Iltimos, mavzuni takrorlab, qayta topshiring.")
    return "\n".join(lines)
