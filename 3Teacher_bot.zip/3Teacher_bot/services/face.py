import config


async def verify_face(image_bytes: bytes) -> dict:
    """
    Verify face using AWS Rekognition.
    Returns mock success when AWS is not configured (for development).
    """
    if not config.AWS_ACCESS_KEY_ID or config.AWS_ACCESS_KEY_ID.startswith("PUT_"):
        print("[FACE] AWS not configured — returning mock success.")
        return {"verified": True, "mock": True}

    try:
        import boto3
        rek = boto3.client(
            "rekognition",
            aws_access_key_id=config.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=config.AWS_SECRET_ACCESS_KEY,
            region_name=config.AWS_REGION,
        )
        response = rek.detect_faces(
            Image={"Bytes": image_bytes},
            Attributes=["ALL"],
        )
        faces = response.get("FaceDetails", [])

        if len(faces) == 0:
            return {"verified": False, "reason": "Yuz aniqlanmadi. Kamerani tekshiring."}
        if len(faces) > 1:
            return {"verified": False, "reason": "Bir nechta yuz aniqlandi. Faqat siz bo'lishingiz kerak."}

        face = faces[0]
        confidence = face.get("Confidence", 0)
        eyes_open = face.get("EyesOpen", {}).get("Value", False)

        if confidence < 90:
            return {"verified": False, "reason": "Yuz sifati past. Yaxshiroq yoritishda urinib ko'ring."}
        if not eyes_open:
            return {"verified": False, "reason": "Ko'zlarni oching va qayta urinib ko'ring."}

        return {"verified": True}

    except Exception as e:
        print(f"[FACE] Rekognition error: {e}")
        return {"verified": False, "reason": f"Texnik xato: {str(e)}"}
