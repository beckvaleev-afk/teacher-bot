import json
import config

# ── Fallback questions used when OpenAI is not configured ─
FALLBACK_QUESTIONS = [
    {
        "question": "Dasturlashda o'zgaruvchi nima?",
        "options": ["A) Satr", "B) Ma'lumotni saqlash joyi", "C) Funksiya", "D) Tsikl"],
        "correct": 1,
    },
    {
        "question": "Python qaysi turdagi til?",
        "options": ["A) Kompilyatsiya qilinadigan", "B) Interpretatsiya qilinadigan", "C) Mashina tili", "D) Assembler"],
        "correct": 1,
    },
    {
        "question": "HTML nima uchun ishlatiladi?",
        "options": ["A) Ma'lumotlar bazasi", "B) Serverlar", "C) Veb-sahifalar tuzilmasi", "D) Operatsion tizim"],
        "correct": 2,
    },
    {
        "question": "Qaysi operatsiya bo'linishni bildiradi?",
        "options": ["A) *", "B) +", "C) -", "D) /"],
        "correct": 3,
    },
    {
        "question": "Git nima?",
        "options": ["A) Dasturlash tili", "B) Versiyalarni boshqarish tizimi", "C) Ma'lumotlar bazasi", "D) Veb-brauzer"],
        "correct": 1,
    },
    {
        "question": "API nima?",
        "options": ["A) Dastur interfeysi", "B) Fayllar tizimi", "C) Operatsion tizim", "D) Tarmoq protokoli"],
        "correct": 0,
    },
    {
        "question": "SQL qaysi maqsadda ishlatiladi?",
        "options": ["A) Tasvirlarni tahrirlash", "B) Ma'lumotlar bazasini boshqarish", "C) Tarmoqlar", "D) Xavfsizlik"],
        "correct": 1,
    },
    {
        "question": "Boolean qiymat nechta holatga ega?",
        "options": ["A) 1", "B) 3", "C) 2", "D) 4"],
        "correct": 2,
    },
    {
        "question": "Loop nima uchun ishlatiladi?",
        "options": ["A) O'zgaruvchi yaratish", "B) Kodni takrorlash", "C) Faylni ochish", "D) Xatolarni bartaraf etish"],
        "correct": 1,
    },
    {
        "question": "Function nima?",
        "options": ["A) Ma'lumotlar turi", "B) Qayta ishlatiladigan kod bloki", "C) Tsikl turi", "D) Operator"],
        "correct": 1,
    },
]


async def generate_questions(topic: str) -> list:
    """
    Generate 10 MCQ questions about the given topic using OpenAI.
    Falls back to generic questions if OpenAI is not configured.
    """
    if not config.OPENAI_API_KEY or config.OPENAI_API_KEY.startswith("PUT_"):
        print("[QUIZ] OpenAI not configured — using fallback questions.")
        return FALLBACK_QUESTIONS

    try:
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=config.OPENAI_API_KEY)

        prompt = f"""Generate exactly 10 multiple choice questions about: "{topic}".

Rules:
- Questions must be relevant to the topic
- Each question has exactly 4 options labeled A), B), C), D)
- Only ONE option is correct
- Questions should test real understanding, not just memorization

Return ONLY a valid JSON array with no explanation, no markdown, no code fences.
Format:
[
  {{
    "question": "Question text here?",
    "options": ["A) option1", "B) option2", "C) option3", "D) option4"],
    "correct": 0
  }}
]
"correct" is the 0-based index (0=A, 1=B, 2=C, 3=D) of the right answer."""

        response = await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=2000,
        )

        raw = response.choices[0].message.content.strip()

        # Strip markdown fences if present
        if raw.startswith("```"):
            lines = raw.split("\n")
            raw = "\n".join(lines[1:-1])

        questions = json.loads(raw)

        # Validate structure
        if not isinstance(questions, list) or len(questions) < 5:
            raise ValueError("Not enough questions returned")

        return questions[:10]

    except Exception as e:
        print(f"[QUIZ] OpenAI error: {e} — using fallback questions.")
        return FALLBACK_QUESTIONS
