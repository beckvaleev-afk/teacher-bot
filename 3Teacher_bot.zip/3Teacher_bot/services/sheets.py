from datetime import datetime
import config


async def log_to_sheets(submission_data: dict, result: dict) -> bool:
    """
    Append one row to Google Sheets.
    Silently skips if Google credentials are not configured.
    """
    if not config.GOOGLE_SHEETS_ID or config.GOOGLE_SHEETS_ID.startswith("PUT_"):
        print("[SHEETS] Google Sheets not configured — skipping log.")
        return False

    try:
        from google.oauth2.service_account import Credentials
        from googleapiclient.discovery import build

        scopes = ["https://www.googleapis.com/auth/spreadsheets"]
        creds = Credentials.from_service_account_file(
            config.GOOGLE_CREDS_JSON, scopes=scopes
        )
        service = build("sheets", "v4", credentials=creds)

        row = [[
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            submission_data.get("full_name", ""),
            submission_data.get("course", ""),
            submission_data.get("group", ""),
            submission_data.get("assignment_type", ""),
            submission_data.get("topic", ""),
            submission_data.get("file_url", ""),
            result.get("score", 0),
            result.get("total", 10),
            result.get("grade", 0),
            result.get("status", ""),
            "Ha" if result.get("passed") else "Yo'q",
        ]]

        service.spreadsheets().values().append(
            spreadsheetId=config.GOOGLE_SHEETS_ID,
            range="Sheet1!A1",
            valueInputOption="RAW",
            insertDataOption="INSERT_ROWS",
            body={"values": row},
        ).execute()

        print(f"[SHEETS] Logged: {submission_data.get('full_name')}")
        return True

    except Exception as e:
        print(f"[SHEETS] Error: {e}")
        return False
