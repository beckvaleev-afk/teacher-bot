import asyncio
import json

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    Message, CallbackQuery,
    InlineKeyboardMarkup, InlineKeyboardButton,
)

from database.db import get_session
from database.models import Submission
from services.s3 import upload_file_to_s3
from services.quiz import generate_questions
from services.grading import calculate_grade, format_result_message
from services.sheets import log_to_sheets
import config

router = Router()

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".pptx"}
QUESTION_TIMEOUT   = 25   # seconds per question
TOTAL_QUESTIONS    = 10


# ══════════════════════════════════════════════════════════
#  FSM States
# ══════════════════════════════════════════════════════════
class StudentFlow(StatesGroup):
    choosing_type   = State()
    entering_name   = State()
    entering_course = State()
    entering_group  = State()
    entering_topic  = State()
    uploading_file  = State()
    face_verify     = State()
    taking_quiz     = State()


# ══════════════════════════════════════════════════════════
#  Step 1 — Choose assignment type
# ══════════════════════════════════════════════════════════
@router.callback_query(F.data.startswith("type:"))
async def chose_assignment_type(cb: CallbackQuery, state: FSMContext):
    atype_map = {
        "independent": "Mustaqil ish",
        "retake":      "Qayta o'zlashtirish",
        "additional":  "Qo'shimcha topshiriq",
    }
    key   = cb.data.split(":")[1]
    atype = atype_map.get(key, key)
    await state.update_data(assignment_type=atype)
    await cb.message.edit_reply_markup(reply_markup=None)
    await cb.message.answer(
        f"✅ Tanlandi: *{atype}*\n\n"
        f"Ism va familiyangizni kiriting.\n"
        f"_(Masalan: Aliyev Ali)_",
        parse_mode="Markdown"
    )
    await state.set_state(StudentFlow.entering_name)
    await cb.answer()


# ══════════════════════════════════════════════════════════
#  Step 2 — Collect student information
# ══════════════════════════════════════════════════════════
@router.message(StudentFlow.entering_name)
async def got_name(msg: Message, state: FSMContext):
    name = msg.text.strip() if msg.text else ""
    parts = name.split()
    if len(parts) < 2:
        return await msg.answer(
            "❗ Iltimos, *ism va familiyangizni* to'liq kiriting.\n"
            "_(Masalan: Aliyev Ali)_",
            parse_mode="Markdown"
        )
    await state.update_data(full_name=name)
    await msg.answer("Kurs raqamini kiriting:\n_(Masalan: 1, 2, 3 yoki 4)_",
                     parse_mode="Markdown")
    await state.set_state(StudentFlow.entering_course)


@router.message(StudentFlow.entering_course)
async def got_course(msg: Message, state: FSMContext):
    course = msg.text.strip() if msg.text else ""
    if not course:
        return await msg.answer("❗ Kurs raqamini kiriting.")
    await state.update_data(course=course)
    await msg.answer("Guruh nomini kiriting:\n_(Masalan: CS-101, MM-22)_",
                     parse_mode="Markdown")
    await state.set_state(StudentFlow.entering_group)


@router.message(StudentFlow.entering_group)
async def got_group(msg: Message, state: FSMContext):
    group = msg.text.strip() if msg.text else ""
    if not group:
        return await msg.answer("❗ Guruh nomini kiriting.")
    await state.update_data(group=group)
    await msg.answer("Topshiriq mavzusini kiriting:\n_(Masalan: Python asoslari)_",
                     parse_mode="Markdown")
    await state.set_state(StudentFlow.entering_topic)


@router.message(StudentFlow.entering_topic)
async def got_topic(msg: Message, state: FSMContext):
    topic = msg.text.strip() if msg.text else ""
    if len(topic) < 3:
        return await msg.answer("❗ Mavzu kamida 3 ta harfdan iborat bo'lishi kerak.")
    await state.update_data(topic=topic)
    await msg.answer(
        "📎 Faylingizni yuboring.\n\n"
        "Ruxsat etilgan formatlar: `.pdf`, `.docx`, `.pptx`",
        parse_mode="Markdown"
    )
    await state.set_state(StudentFlow.uploading_file)


# ══════════════════════════════════════════════════════════
#  Step 3 — File upload
# ══════════════════════════════════════════════════════════
@router.message(StudentFlow.uploading_file, F.document)
async def got_file(msg: Message, state: FSMContext):
    doc = msg.document
    filename = doc.file_name or "file"
    ext = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

    if ext not in ALLOWED_EXTENSIONS:
        return await msg.answer(
            f"❗ Faqat `.pdf`, `.docx`, `.pptx` formatlari qabul qilinadi.\n"
            f"Siz yubordingiz: `{ext}`",
            parse_mode="Markdown"
        )

    uploading_msg = await msg.answer("⏳ Fayl yuklanmoqda...")

    try:
        tg_file   = await msg.bot.get_file(doc.file_id)
        file_data = await msg.bot.download_file(tg_file.file_path)
        s3_url    = await upload_file_to_s3(file_data.read(), filename)
        await state.update_data(file_url=s3_url)
    except Exception as e:
        await uploading_msg.edit_text(f"❌ Fayl yuklanishda xato: {e}")
        return

    await uploading_msg.edit_text("✅ Fayl saqlandi!")

    # Check if WebApp URL is configured for real face verification
    if config.WEBAPP_URL.startswith("https://yourdomain"):
        # Skip face verification in dev mode
        await msg.answer(
            "⚠️ *Dev rejim:* Yuz tasdiqlash o'tkazib yuborildi.\n\n"
            "Test boshlanyapti...",
            parse_mode="Markdown"
        )
        await state.set_state(StudentFlow.taking_quiz)
        await start_quiz(msg, state)
    else:
        face_kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(
                text="📷 Yuzni tasdiqlash",
                web_app={"url": config.WEBAPP_URL}  # type: ignore
            )
        ]])
        await msg.answer(
            "✅ Fayl qabul qilindi!\n\n"
            "Endi yuzingizni tasdiqlang. Quyidagi tugmani bosing:",
            reply_markup=face_kb
        )
        await state.set_state(StudentFlow.face_verify)


@router.message(StudentFlow.uploading_file)
async def file_wrong_type(msg: Message):
    await msg.answer(
        "❗ Iltimos, fayl yuboring (`.pdf`, `.docx` yoki `.pptx`).",
        parse_mode="Markdown"
    )


# ══════════════════════════════════════════════════════════
#  Step 4 — Face verification (WebApp result)
# ══════════════════════════════════════════════════════════
@router.message(StudentFlow.face_verify, F.web_app_data)
async def face_webapp_result(msg: Message, state: FSMContext):
    try:
        data = json.loads(msg.web_app_data.data)
    except Exception:
        data = {}

    if data.get("verified"):
        await msg.answer("✅ Yuz muvaffaqiyatli tasdiqlandi!\n\nTest boshlanyapti...")
        await state.set_state(StudentFlow.taking_quiz)
        await start_quiz(msg, state)
    else:
        reason = data.get("reason", "Noma'lum xato")
        retry_kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(
                text="🔄 Qayta urinish",
                web_app={"url": config.WEBAPP_URL}  # type: ignore
            )
        ]])
        await msg.answer(
            f"❌ Yuz tasdiqlanmadi.\nSabab: {reason}\n\nQayta urinib ko'ring:",
            reply_markup=retry_kb
        )


# ══════════════════════════════════════════════════════════
#  Step 5 — Quiz engine
# ══════════════════════════════════════════════════════════
async def start_quiz(msg: Message, state: FSMContext):
    data = await state.get_data()
    topic = data.get("topic", "Umumiy")

    wait_msg = await msg.answer(f"🤖 *{topic}* mavzusida savollar tayyorlanmoqda...",
                                parse_mode="Markdown")
    questions = await generate_questions(topic)
    await wait_msg.delete()

    await state.update_data(
        questions=questions,
        q_index=0,
        correct=0,
        wrong=0,
    )
    await send_question(msg, state)


def make_question_keyboard(options: list) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=opt, callback_data=f"ans:{i}")]
        for i, opt in enumerate(options)
    ])


async def send_question(msg: Message, state: FSMContext):
    data = await state.get_data()
    idx       = data["q_index"]
    questions = data["questions"]

    if idx >= len(questions):
        await finish_quiz(msg, state)
        return

    q = questions[idx]
    kb = make_question_keyboard(q["options"])

    sent = await msg.answer(
        f"❓ *Savol {idx + 1}/{TOTAL_QUESTIONS}*\n\n"
        f"{q['question']}\n\n"
        f"⏱ {QUESTION_TIMEOUT} soniya",
        reply_markup=kb,
        parse_mode="Markdown"
    )

    # Store the message id so the timer can edit it
    await state.update_data(current_msg_id=sent.message_id)

    # Schedule auto-advance after timeout
    asyncio.create_task(
        auto_advance_timer(msg.chat.id, msg.bot, state, idx, sent.message_id)
    )


async def auto_advance_timer(chat_id: int, bot, state: FSMContext,
                              expected_idx: int, msg_id: int):
    await asyncio.sleep(QUESTION_TIMEOUT)

    current_data = await state.get_data()
    if current_data.get("q_index") != expected_idx:
        return  # Student already answered

    # Auto-advance: treat as wrong answer
    new_idx   = expected_idx + 1
    new_wrong = current_data.get("wrong", 0) + 1
    await state.update_data(q_index=new_idx, wrong=new_wrong)

    try:
        await bot.edit_message_reply_markup(
            chat_id=chat_id, message_id=msg_id, reply_markup=None
        )
    except Exception:
        pass

    await bot.send_message(chat_id, "⏰ Vaqt tugadi! Keyingi savol...")

    # Reconstruct a minimal Message-like object for send_question
    class FakeMsg:
        def __init__(self):
            self.chat = type("C", (), {"id": chat_id})()
            self.bot  = bot

        async def answer(self, text, **kwargs):
            return await bot.send_message(chat_id, text, **kwargs)

    await send_question(FakeMsg(), state)


@router.callback_query(StudentFlow.taking_quiz, F.data.startswith("ans:"))
async def got_answer(cb: CallbackQuery, state: FSMContext):
    data      = await state.get_data()
    idx       = data["q_index"]
    questions = data["questions"]

    if idx >= len(questions):
        await cb.answer()
        return

    chosen    = int(cb.data.split(":")[1])
    correct_i = questions[idx]["correct"]
    is_right  = chosen == correct_i

    new_correct = data["correct"] + (1 if is_right else 0)
    new_wrong   = data["wrong"]   + (0 if is_right else 1)

    await state.update_data(
        q_index=idx + 1,
        correct=new_correct,
        wrong=new_wrong,
    )

    # Remove keyboard from question message
    try:
        await cb.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass

    icon = "✅" if is_right else "❌"
    await cb.message.answer(icon)
    await cb.answer(icon)

    await send_question(cb.message, state)


# ══════════════════════════════════════════════════════════
#  Step 6 — Grade + save results
# ══════════════════════════════════════════════════════════
async def finish_quiz(msg: Message, state: FSMContext):
    data    = await state.get_data()
    correct = data.get("correct", 0)
    result  = calculate_grade(correct, TOTAL_QUESTIONS)

    result_text = format_result_message(result, data.get("full_name", "Talaba"))
    await msg.answer(result_text, parse_mode="Markdown")

    # Save to database
    try:
        async with get_session() as session:
            sub = Submission(
                telegram_id     = msg.chat.id,
                full_name       = data.get("full_name", ""),
                course          = data.get("course", ""),
                group           = data.get("group", ""),
                assignment_type = data.get("assignment_type", ""),
                topic           = data.get("topic", ""),
                file_url        = data.get("file_url", ""),
                score           = result["score"],
                grade           = result["grade"],
                status          = result["status"],
                passed          = "Ha" if result["passed"] else "Yo'q",
            )
            session.add(sub)
        print(f"[DB] Saved: {data.get('full_name')} — {result['score']}/10")
    except Exception as e:
        print(f"[DB] Save error: {e}")

    # Log to Google Sheets
    await log_to_sheets(data, result)

    await msg.answer(
        "Barcha natijalar saqlandi.\n"
        "Qayta topshirish uchun /start ni bosing."
    )
    await state.clear()
