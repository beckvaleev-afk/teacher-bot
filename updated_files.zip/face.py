"""
Face verification using OpenCV Haar Cascades.
100% free, runs locally, no API keys needed.
"""
import base64
import os
import urllib.request

import cv2
import numpy as np


# ── Haar Cascade loader ───────────────────────────────────
def _get_cascade_path(filename: str) -> str:
    """Find OpenCV built-in cascade XML, or download it."""
    cv2_dir = os.path.dirname(cv2.__file__)
    candidates = [
        os.path.join(cv2_dir, "data", filename),
        os.path.join(cv2_dir, filename),
        os.path.join(os.path.dirname(cv2_dir), "data", filename),
    ]
    for path in candidates:
        if os.path.exists(path):
            return path
    # Fallback: save next to this file
    local_path = os.path.join(os.path.dirname(__file__), filename)
    if not os.path.exists(local_path):
        url = (
            "https://raw.githubusercontent.com/opencv/opencv/"
            f"master/data/haarcascades/{filename}"
        )
        print(f"[FACE] Downloading {filename}...")
        urllib.request.urlretrieve(url, local_path)
    return local_path


# Load once at import time
try:
    _face_cascade = cv2.CascadeClassifier(
        _get_cascade_path("haarcascade_frontalface_default.xml")
    )
    _eye_cascade = cv2.CascadeClassifier(
        _get_cascade_path("haarcascade_eye.xml")
    )
    print("[FACE] OpenCV cascades loaded successfully.")
except Exception as _e:
    print(f"[FACE] Warning — could not load cascades: {_e}")
    _face_cascade = None
    _eye_cascade  = None


# ── Image helpers ─────────────────────────────────────────
def _from_bytes(image_bytes: bytes):
    arr = np.frombuffer(image_bytes, dtype=np.uint8)
    return cv2.imdecode(arr, cv2.IMREAD_COLOR)


def _from_base64(b64: str):
    if "," in b64:                        # strip data:image/jpeg;base64,
        b64 = b64.split(",", 1)[1]
    return _from_bytes(base64.b64decode(b64))


# ── Core detection ────────────────────────────────────────
def _run_detection(img) -> dict:
    """
    Run Haar Cascade face + eye detection on an OpenCV image.
    Checks:
      1. Exactly one face present
      2. At least one eye visible (basic liveness)
      3. Face is large enough in frame
    """
    if _face_cascade is None:
        return {"verified": False, "reason": "Detektor yuklanmadi. Botni qayta ishga tushiring."}

    if img is None:
        return {"verified": False, "reason": "Rasm o'qilmadi."}

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)   # boost contrast

    faces = _face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(80, 80),
        flags=cv2.CASCADE_SCALE_IMAGE,
    )

    if len(faces) == 0:
        return {
            "verified": False,
            "reason": (
                "Yuz aniqlanmadi.\n"
                "• Yaxshi yoritilgan joyda turing\n"
                "• Kameraga to'g'ridan qarang\n"
                "• Yuzingizni to'liq ko'rsating"
            ),
        }

    if len(faces) > 1:
        return {
            "verified": False,
            "reason": f"{len(faces)} ta yuz aniqlandi. Faqat siz bo'lishingiz kerak.",
        }

    # Single face — check eyes
    x, y, w, h = faces[0]
    face_gray = gray[y : y + h, x : x + w]
    eyes = _eye_cascade.detectMultiScale(
        face_gray,
        scaleFactor=1.1,
        minNeighbors=3,
        minSize=(20, 20),
    )

    if len(eyes) == 0:
        return {
            "verified": False,
            "reason": (
                "Ko'zlar aniqlanmadi.\n"
                "• Ko'zlaringizni oching\n"
                "• Kameraga to'g'ridan qarang\n"
                "• Ko'zoynak bo'lsa olib ko'ring"
            ),
        }

    # Face size check — must cover at least 4% of frame
    coverage = (w * h) / (img.shape[0] * img.shape[1])
    if coverage < 0.04:
        return {
            "verified": False,
            "reason": "Yuz juda kichik ko'rinmoqda. Kameraga yaqinroq keling.",
        }

    print(f"[FACE] Tasdiqlandi — 1 yuz, {len(eyes)} ko'z, {coverage:.1%} kadr")
    return {"verified": True}


# ── Public API ────────────────────────────────────────────
async def verify_face(image_bytes: bytes) -> dict:
    """Verify face from raw image bytes (used by bot photo handler)."""
    return _run_detection(_from_bytes(image_bytes))


async def verify_face_base64(b64_string: str) -> dict:
    """Verify face from base64 string (used by WebApp POST)."""
    return _run_detection(_from_base64(b64_string))
