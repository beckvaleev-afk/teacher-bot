"""
Student flow FSM — complete step-by-step handler.
Face verification uses OpenCV (local, free, no API needed).
Students send a selfie photo directly in chat for verification.
"""
import asyncio

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    Message, CallbackQuery,
    InlineKeyboardMarkup, InlineKeyboardButton,
)

from database.db import get_session
from database.models import Submission
from services.s3 import upload_file_to_s3
from services.face_new import verify_face
from services.quiz import generate_questions
from services.grading import calculate_grade, format_result_message
from services.sheets import log_to_sheets

router = Router()

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".pptx"}
QUESTION_TIMEOUT   = 25
TOTAL_QUESTIONS    = 10


class StudentFlow(StatesGroup):
    choosing_type   = State()
    entering_name   = State()
    entering_course = State()
    entering_group  = State()
    entering_topic  = State()
    uploading_file  = State()
    face_verify     = State()
    taking_quiz     = State()


@router.callback_query(F.data.startswith("type:"))
async def chose_assignment_type(cb: CallbackQuery, state: FSMContext):
    atype_map = {
        "independent": "Mustaqil ish",
        "retake":      "Qayta o'zlashtirish",
        "additional":  "Qo'shimcha topshiriq",
    }
    atype = atype_map.get(cb.data.split(":")[1], cb.data.split(":")[1])
    await state.update_data(assignment_type=atype)
    await cb.message.edit_reply_markup(reply_markup=None)
    await cb.message.answer(
        f"✅ Tanlandi: *{atype}*\n\nIsm va familiyangizni kiriting.\n_(Masalan: Aliyev Ali)_",
        parse_mode="Markdown",
    )
    await state.set_state(StudentFlow.entering_name)
    await cb.answer()


@router.message(StudentFlow.entering_name)
async def got_name(msg: Message, state: FSMContext):
    name = msg.text.strip() if msg.text else ""
    if len(name.split()) < 2:
        return await msg.answer("❗ Iltimos, *ism va familiyangizni* to'liq kiriting.\n_(Masalan: Aliyev Ali)_", parse_mode="Markdown")
    await state.update_data(full_name=name)
    await msg.answer("Kurs raqamini kiriting:\n_(Masalan: 1, 2, 3 yoki 4)_", parse_mode="Markdown")
    await state.set_state(StudentFlow.entering_course)


@router.message(StudentFlow.entering_course)
async def got_course(msg: Message, state: FSMContext):
    course = msg.text.strip() if msg.text else ""
    if not course:
        return await msg.answer("❗ Kurs raqamini kiriting.")
    await state.update_data(course=course)
    await msg.answer("Guruh nomini kiriting:\n_(Masalan: CS-101, MM-22)_", parse_mode="Markdown")
    await state.set_state(StudentFlow.entering_group)


@router.message(StudentFlow.entering_group)
async def got_group(msg: Message, state: FSMContext):
    group = msg.text.strip() if msg.text else ""
    if not group:
        return await msg.answer("❗ Guruh nomini kiriting.")
    await state.update_data(group=group)
    await msg.answer("Topshiriq mavzusini kiriting:\n_(Masalan: Python asoslari)_", parse_mode="Markdown")
    await state.set_state(StudentFlow.entering_topic)


@router.message(StudentFlow.entering_topic)
async def got_topic(msg: Message, state: FSMContext):
    topic = msg.text.strip() if msg.text else ""
    if len(topic) < 3:
        return await msg.answer("❗ Mavzu kamida 3 ta harfdan iborat bo'lishi kerak.")
    await state.update_data(topic=topic)
    await msg.answer("📎 Faylingizni yuboring.\n\nRuxsat etilgan formatlar: `.pdf`, `.docx`, `.pptx`", parse_mode="Markdown")
    await state.set_state(StudentFlow.uploading_file)


@router.message(StudentFlow.uploading_file, F.document)
async def got_file(msg: Message, state: FSMContext):
    doc      = msg.document
    filename = doc.file_name or "file"
    ext      = ("." + filename.rsplit(".", 1)[-1].lower()) if "." in filename else ""
    if ext not in ALLOWED_EXTENSIONS:
        return await msg.answer(f"❗ Faqat `.pdf`, `.docx`, `.pptx` formatlari qabul qilinadi.\nSiz yubordingiz: `{ext}`", parse_mode="Markdown")

    wait = await msg.answer("⏳ Fayl yuklanmoqda...")
    try:
        tg_file   = await msg.bot.get_file(doc.file_id)
        file_data = await msg.bot.download_file(tg_file.file_path)
        s3_url    = await upload_file_to_s3(file_data.read(), filename)
        await state.update_data(file_url=s3_url)
    except Exception as e:
        return await wait.edit_text(f"❌ Fayl yuklanishda xato: {e}")

    await wait.edit_text("✅ Fayl saqlandi!")
    await msg.answer(
        "📸 *Yuz tasdiqlash*\n\n"
        "Endi o'zingizning *selfi rasmingizni* yuboring.\n\n"
        "Talablar:\n"
        "• Yuzingiz to'liq ko'rinsin\n"
        "• Yaxshi yoritilgan joy\n"
        "• Ko'zlaringizni oching\n"
        "• Faqat siz bo'ling",
        parse_mode="Markdown",
    )
    await state.set_state(StudentFlow.face_verify)


@router.message(StudentFlow.uploading_file)
async def file_wrong_type(msg: Message):
    await msg.answer("❗ Iltimos, fayl yuboring (`.pdf`, `.docx` yoki `.pptx`).", parse_mode="Markdown")


@router.message(StudentFlow.face_verify, F.photo)
async def got_selfie(msg: Message, state: FSMContext):
    checking = await msg.answer("🔍 Yuz tekshirilmoqda...")
    try:
        photo    = msg.photo[-1]
        tg_file  = await msg.bot.get_file(photo.file_id)
        img_data = await msg.bot.download_file(tg_file.file_path)
        result   = await verify_face(img_data.read())
    except Exception as e:
        await checking.edit_text(f"❌ Texnik xato: {e}\nQayta urinib ko'ring.")
        return

    if result["verified"]:
        await checking.edit_text("✅ Yuz muvaffaqiyatli tasdiqlandi!")
        await msg.answer("🎯 Test boshlanyapti...")
        await state.set_state(StudentFlow.taking_quiz)
        await start_quiz(msg, state)
    else:
        reason = result.get("reason", "Noma'lum xato")
        await checking.edit_text(
            f"❌ *Yuz tasdiqlanmadi*\n\n{reason}\n\nQayta selfi yuboring:",
            parse_mode="Markdown",
        )


@router.message(StudentFlow.face_verify)
async def face_wrong_input(msg: Message):
    await msg.answer("📸 Iltimos, *selfi rasm* yuboring (hujjat yoki matn emas).", parse_mode="Markdown")


async def start_quiz(msg: Message, state: FSMContext):
    data  = await state.get_data()
    topic = data.get("topic", "Umumiy")
    wait  = await msg.answer(f"🤖 *{topic}* mavzusida savollar tayyorlanmoqda...", parse_mode="Markdown")
    questions = await generate_questions(topic)
    await wait.delete()
    await state.update_data(questions=questions, q_index=0, correct=0, wrong=0)
    await send_question(msg, state)


def _question_keyboard(options: list) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=opt, callback_data=f"ans:{i}")]
        for i, opt in enumerate(options)
    ])


async def send_question(msg: Message, state: FSMContext):
    data      = await state.get_data()
    idx       = data["q_index"]
    questions = data["questions"]
    if idx >= len(questions):
        await finish_quiz(msg, state)
        return
    q    = questions[idx]
    sent = await msg.answer(
        f"❓ *Savol {idx + 1}/{TOTAL_QUESTIONS}*\n\n{q['question']}\n\n⏱ {QUESTION_TIMEOUT} soniya",
        reply_markup=_question_keyboard(q["options"]),
        parse_mode="Markdown",
    )
    await state.update_data(current_msg_id=sent.message_id)
    asyncio.create_task(_auto_advance(msg.chat.id, msg.bot, state, idx, sent.message_id))


async def _auto_advance(chat_id: int, bot, state: FSMContext, expected_idx: int, msg_id: int):
    await asyncio.sleep(QUESTION_TIMEOUT)
    data = await state.get_data()
    if data.get("q_index") != expected_idx:
        return
    await state.update_data(q_index=expected_idx + 1, wrong=data.get("wrong", 0) + 1)
    try:
        await bot.edit_message_reply_markup(chat_id=chat_id, message_id=msg_id, reply_markup=None)
    except Exception:
        pass
    await bot.send_message(chat_id, "⏰ Vaqt tugadi! Keyingi savol...")

    class _FakeMsg:
        chat = type("C", (), {"id": chat_id})()
        def __init__(self): self.bot = bot
        async def answer(self, text, **kw): return await bot.send_message(chat_id, text, **kw)

    await send_question(_FakeMsg(), state)


@router.callback_query(StudentFlow.taking_quiz, F.data.startswith("ans:"))
async def got_answer(cb: CallbackQuery, state: FSMContext):
    data      = await state.get_data()
    idx       = data["q_index"]
    questions = data["questions"]
    if idx >= len(questions):
        await cb.answer()
        return
    chosen   = int(cb.data.split(":")[1])
    is_right = chosen == questions[idx]["correct"]
    await state.update_data(
        q_index = idx + 1,
        correct = data["correct"] + (1 if is_right else 0),
        wrong   = data["wrong"]   + (0 if is_right else 1),
    )
    try:
        await cb.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass
    icon = "✅" if is_right else "❌"
    await cb.message.answer(icon)
    await cb.answer(icon)
    await send_question(cb.message, state)


async def finish_quiz(msg: Message, state: FSMContext):
    data   = await state.get_data()
    result = calculate_grade(data.get("correct", 0), TOTAL_QUESTIONS)
    await msg.answer(format_result_message(result, data.get("full_name", "Talaba")), parse_mode="Markdown")
    try:
        async with get_session() as session:
            session.add(Submission(
                telegram_id     = msg.chat.id,
                full_name       = data.get("full_name", ""),
                course          = data.get("course", ""),
                group           = data.get("group", ""),
                assignment_type = data.get("assignment_type", ""),
                topic           = data.get("topic", ""),
                file_url        = data.get("file_url", ""),
                score           = result["score"],
                grade           = result["grade"],
                status          = result["status"],
                passed          = "Ha" if result["passed"] else "Yo'q",
            ))
        print(f"[DB] Saqlandi: {data.get('full_name')} — {result['score']}/10")
    except Exception as e:
        print(f"[DB] Xato: {e}")
    await log_to_sheets(data, result)
    await msg.answer("Barcha natijalar saqlandi.\nQayta topshirish uchun /start ni bosing.")
    await state.clear()
